$regfile="m32def.dat"

$crystal=1000000

config PORTd.7=OUTPUT
config PORTD.4=OUTPUT
config PORTD.6=OUTPUT
config PORTB.0=OUTPUT
config PORTa.0=INPUT

dim P as long,R as integer

set portd.6
reset portd.7

do
   pulseout portb,0,20
   pulsein P,pina,0,1
   R=P*20
   R=R/58
   if R<=15 then
      set PORTd.4
      set PORTd.7
      wait 1
      reset portd.4
      reset portd.7
      wait 3
   else
      reset PORTd.4
      reset PORTd.7
   end IF
loop
end